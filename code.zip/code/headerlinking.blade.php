<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="" name="keywords">
<meta content="" name="description">

  <!-- Favicons -->
  <link href="{{url('front/img/favicon.png')}}" rel="icon">
   <link href="{{url('front/img/favicon.png')}}" rel="pujarijii-icon">


  <!-- Bootstrap CSS File -->
  <link href="{{url('front/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="{{url('front/vendor/icofont/icofont.min.css')}}" rel="stylesheet">
  <link href="{{url('front/vendor/line-awesome/css/line-awesome.min.css')}}" rel="stylesheet">
  <link href="{{url('front/vendor/aos/aos.css')}}" rel="stylesheet">
  <link href="{{url('front/vendor/owlcarousel/assets/owl.carousel.min.css')}}" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="{{url('front/css/style.css')}}" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
