<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        {{-- <div class="mb-2 mb-md-0">
            ©
            <script>
                document.write(new Date().getFullYear());
            </script>
            <a href="https://hindtechitsolutions.com/" target="_blank" class="footer-link fw-bolder">Designed & Developed By <u>Hindtech It Solutions</u></a>
        </div> --}}
        {{-- <div>
            <a href="https://hindtechitsolutions.com/" target="_blank" class="footer-link me-4">Support</a>
        </div> --}}
    </div>
</footer>
